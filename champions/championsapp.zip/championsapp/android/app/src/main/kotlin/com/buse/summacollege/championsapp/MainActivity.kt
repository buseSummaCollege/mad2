package com.buse.summacollege.championsapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
